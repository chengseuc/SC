    

clear all; close all;
% load covariance function
% add functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load functions to generate random variables
% Load separable model MCMC_operations
%addpath ./GP_operations;

% load functions to generate random variables 

% load NNGP operations
 addpath ~/NNGPfunctions
 addpath ~\AllD_cokriging
 addpath ~\NNCGP_code_package
 % load Data



    B1= 10;
    B2= 1;
    
    
    sigma1_orin = 2;
    tau1_orin = 0.1;
    phi1_orin = 10;

    sigma2_orin= 1;
    tau2_orin = 0.05;
    phi2_orin = 10;
  

    t_nugget = 0.001;

%%%%% Grid reference constuction %%%%%%%

number = 100;

N = [number number];
x = (1:N(1))/N(1);
y = (1:N(2))/N(2);

coordr = [kron(ones(N(2),1),x') kron(y',ones(N(1),1))];

n0 = N(1)*N(2);


coordall = coordr;

coordX = [ones(n0,1) coordall];

    D = pdist(coordall);
    D = squareform(D);
    R1 = exp(-phi1_orin*D)+t_nugget*eye((n0));
    R2 = exp(-phi2_orin*D)+t_nugget*eye((n0));

    Q_R1 = chol(R1); 
    Q_R2 = chol(R2); 

    x1=ones((n0),1);
    x2=ones((n0),1);

    %zeta1_orin = beta_zeta1_orin + coordall*beta_zeta2_orin'*0.01;
    %zeta1_orin = coordX*beta_zeta_orin';
    zeta1_orin = 1;
    
    w1 = sigma1_orin*Q_R1'*normrnd(0,1,[n0,1]);
    y1 = x1*B1+w1+normrnd(0,sqrt(tau1_orin),[n0,1]);
    w2 = sigma2_orin*Q_R2'*normrnd(0,1,[n0,1]);
    %y2 = zeta1_orin.*(x2*B1+w1)+x2*B2+w2+normrnd(0,sqrt(tau2_orin),[n0,1]);
    y2 = zeta1_orin.*y1+x2*B2+w2+normrnd(0,sqrt(tau2_orin),[n0,1]);


    data1 = [y1 coordall];
    data2 = [y2 coordall];


    
    
longip1 = data1(:,2);
latip1 = data1(:,3);
longip2 = data2(:,2);
latip2 = data2(:,3);






%yy1(1620:3240) = zeros(size(1620:3240,2),1);
 
 %+0.5*(exp(sin((0.9.*((Xxx(:,1)+2)/8+0.48)).^(10))));%+0.5*(Xxx(:,1)/3).*sin(10*cos(2*(Xxx(:,1)/12)*pi))+1+norm_r(0,0.001,size(Xxx,1));%+0.1*sin(10*cos(2*(Xxx(:,1)/12)*pi));%+0.1*cos(2*(Xxx(:,2))*pi)+0.5+0.1*Xxx(:,2);
  %figure; scaterplot(x1,x2,y1); set(gca,'YDir','normal')
  
  % x:20-40, y:30-40

  
  %chunkx = [10 60 40 10 65 60 90]'; chunky = [70 65 20 10 80 40 20]'; widthx = [20 10 10 10 15 20 9]'; widthy = [20 10 30 20 20 20 30]';
  
  
  %chunkx = [50 70 20]'; chunky = [40 30 30]'; widthx = [10 10 10]'; widthy = [10 10 10]';
  
  chunkx = [45 65]'; chunky = [60 20]'; widthx = [20 15]'; widthy = [20 20]';
  
  
chunkx = chunkx/(100/number);
chunky = chunky/(100/number);
widthx = widthx/(100/number);
widthy = widthy/(100/number);
  
  chunk = [];
  
  
  for i = 1:size(chunkx,1)
  for j = chunky(i):(chunky(i)+widthy(i)-1)
  chunk = [chunk (j*number+chunkx(i)):(j*number+chunkx(i)+widthx(i))];
  end
  end
  
  
    data1 = [y1 coordall];
    data2 = [y2 coordall];

    data12 = data2(chunk,:);
    data2(chunk,:)=[]; 
    data22 = [y2 coordall];
    coordall1 = coordall;
    coordall1(chunk,:)=[];
    n1 = n0-size(chunk,2);
    
    z1 = data1(:,1);
    z2 = data2(:,1);
    z2test = data12(:,1);
    z3 = y2-y1;
    
    y12 = y1;
    y12(chunk)=[];
    w12 = w1;
    w12(chunk)=[];

    
testy=data1(:,1);
testy(chunk)=[];
testy1=data1(chunk,1);
testy2 = data22(:,1);
testy2(chunk)=[];
longip = data1(:,2);
latip = data1(:,3);

longip2<-longip;
latip2<-latip;

longip2(chunk,:)=[];
latip2(chunk,:)=[];


obs_loce=coordall(chunk,:); %pairwise longi and lati
obsloce0 = obs_loce;


m=10;

niter = 25000;

iter = 1;


[out,zt] = NNCGP_nest_main(data1,data2,obsloce0,niter,m);



beta1_samp = out(:,1);
beta2_samp = out(:,2);
sig2_samp1 = out(:,3);
sig2_samp2 = out(:,4);
phi1_samp = out(:,5);
phi2_samp = out(:,6);
tau2_samp1 = out(:,7);
tau2_samp2 = out(:,8);
zeta_samp = out(:,9);

  save('test2_nested.mat','beta1_samp','phi1_samp','tau2_samp1','sig2_samp1','beta2_samp','phi2_samp','tau2_samp2','sig2_samp2','zeta_samp','zt');






