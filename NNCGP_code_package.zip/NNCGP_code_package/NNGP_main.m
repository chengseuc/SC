function [out,zt_samp] = NNGP_main(data1,obsloce0,niter,m)




% inputs--

% data1:  dataset of low fidelity level, should be a 3 column matrix with column 1 as
% observation, column 2 as longitude location and column 3 as latitude
% location;

% obsloce0:  the prediction location input, should be a 2 column matrix
% with column 1 as lingitude and column 2 as latitude

% niter:  number of iterations in MCMC(choose by user)

% m:  number of nearest neighbors(choose by user)




% outputs--

% out: a niter by 4 matrix with

% column 1: mean parameter beta_1, sec.4

% column 2: varance parameter sigma_1^2, sec.4

% column 3: spatial effect parameter phi_1 of 2D isotropic setting, sec.4  

% column 4: nugget effect parameter tau_1^2, sec.4 





zt = data1(:,1);

z_data = zt;

%%
longi=data1(:,2);
lati=data1(:,3);
DATT=[z_data longi lati];
[C,Unq,ic] = unique(DATT(:,2:3),'rows');
lon =longi;%longi*pi/180; %
lat =lati;%lati*pi/180;%
No= size(z_data,1);
zvec_orig=z_data;%reshape(z, nx*ny,1); % z
lon_orig=lon;%reshape(xloc,nx*ny,1); %xloc
lat_orig=lat;%reshape(yloc,nx*ny,1); %yloc
xloc=lon;
yloc=lat;         
obsloc=[xloc,yloc];

    
    %%
    
   
%%%% parent correlation function in NNGP
%funname='Gneiting';
funname='exp';
%funname='exp_paper';

%%%% prior dist for parameters
Vbeta=10000;
% tau2\sim IG(a1,b1)
a1=2;
b1=0.1;
% sig2 \sim IG(a2,b2)
a2=2;
b2=1;
% phi \sim Unif (a3,b3)
a3=0.000001*ones(1,2);

%%%%% pre-allocated quantities to hold MCMC samples

% kappa_samp(1) = 0.8;
% alpha_samp(1) = 0.5;
%%%% proposal variance
Delta.sigma2=0.2; 
Delta.mean_sig2 = 3;
Delta.cov_sig2 = 0.1;

Delta.phi = [0.3, 0.3];
Delta.mean_phi = [1,  1];
Delta.cov_phi = [0.3,  0.3];
%b3=(max(obsloc) - min(obsloc));
b3 = [20 20];
Delta.beta = 0.3;
theta.tau2=0.1;
theta.sig2=1; 
theta.phi = [1 1];
theta.covflag = 0;



Zvec_orig=zt;
locvec_orig=data1(:,2:3);
index_total=locvec_orig(:,1);% different sorting may be used;%(xlocvec_orig-min(X)).^1+(ylocvec_orig-min(Y)).^1;
index_total_vec=index_total(:);
[~, ind_I_vec]=sort(index_total_vec);

Zvec_sorted=Zvec_orig(ind_I_vec);
Zdata=Zvec_sorted;
obsloc_sorted=locvec_orig(ind_I_vec,:);
Dim_x=size(obsloc_sorted,2);
No=size(obsloc_sorted,1);

Xm=ones(No,1);

Beta = (Xm'*Xm)\(Xm'*Zdata);  
p=size(Xm,2);
c2=var(Zdata-(Xm*Beta))+20;

c1=1;
prior.Vbeta=Vbeta;
prior.a1 = a1;
prior.b1 = b1;
prior.a2 = a2;
prior.b2 = b2;
prior.a3 = a3;
prior.b3 = b3;
prior.c1 = c1;
prior.c2 = c2;
theta.Beta=Beta;

[array_C,array_rho, B_rowin, B_colin,neigh_index]=NeighD_AllD(obsloc_sorted,m);
neigh_index = int32(neigh_index);

[array_C_p,array_rho_p, B_rowin_p, B_colin_p,neigh_index_p]=NeighD_AllDpr(obsloc_sorted,m,obsloce0);
neigh_index_p = int32(neigh_index);

phi_curr=theta.phi;
sig2_curr=theta.sig2;
%beta_curr=theta.Beta;
tau2=theta.tau2;

a1=prior.a1;
b1=prior.b1;
Vbeta=prior.Vbeta;

No=size(obsloc_sorted,1);
nsub=No;
w_samp=zeros([No 4]);
%w2_samp=zeros([nsub 4]);
mubeta=zeros(p,1);
beta_samp=zeros([p niter]);
phi_samp=zeros([niter 1]);
tau2_samp=zeros([niter 1]);
sig2_samp=zeros([niter 1]);
kappa_samp=zeros(niter, 1);
alpha_samp=zeros(niter, 1);

%%%% initial values to start MCMC

sig2_samp(1)=var(zt);%parr(1);

tau2_samp(1)=tau2;
phi_samp(1) = 10;
beta_samp(:,1)=0;
theta_curr=theta;

  Ne=size(obsloce0,1);

zt_samp=zeros([Ne 1]);
Vzt_iter=zeros([Ne 1]);
wt_samp=zeros([Ne 1]);

iter=1;


n2 = size(obsloce0,1);

Xe=ones((n2),1);

for iter=1:niter

    if mod(iter,20)==0
        display(['Iteration: ' int2str(iter)]);
        disp([beta_curr.', theta_curr.sig2, theta_curr.tau2, theta_curr.phi])
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

    % update beta
    tau2_curr=tau2_samp(iter);
    w_curr=w_samp(:,2);
    Sig_beta_inv=(1/Vbeta*eye(p)+(1/tau2_curr)*(Xm'*Xm));
    mu_ast_beta=(1/Vbeta)*mubeta+(1/tau2_curr) *Xm'*(Zdata-w_curr);
    
    mu_post_beta=Sig_beta_inv\mu_ast_beta;
    R=chol(Sig_beta_inv);
    beta_samp(:,iter+1)=mu_post_beta+R\randn(p,1); 

    beta_curr=beta_samp(:,iter+1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%%%% update w
    [cond_sig2,w_prop]=update_w_test1(Zdata,Xm,B_rowin,B_colin,beta_curr,theta_curr,array_rho,...
        array_C,funname);
    

  indx2=(Ne*m);
  w_nei=w_prop(B_colin_p(1:indx2),:);
  wNt = reshape(w_nei, m, indx2/m);
    % update tau2
    w_samp(:,3)=w_prop;
    w_curr=w_samp(:,3);
    a_new=a1+No/2;
    b_new=b1+0.5*((Zdata-Xm*beta_curr-w_curr)'*(Zdata-Xm*beta_curr-w_curr));
    
    tau2_samp(iter+1)=1/gamrnd(a_new,1/b_new);
    theta_curr.tau2 = tau2_samp(iter+1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%% loglikelihood evaluation given current updated parameters
    
    [wsigma2s, wmus, loglike_curr]=NNGP_loglik_test1(w_curr,neigh_index, ...
        theta_curr, array_rho,array_C,funname);
    
    % Delta.iter=iter;
    [theta_curr,loglike_curr, wmus,wsigma2s, Delta]=... 
    NNGP_MwH_Gibbs_test1(w_curr,neigh_index,loglike_curr, theta_curr, prior, ...
    Delta,array_rho,array_C,funname);

    phi_samp(iter+1) = theta_curr.phi(1);  

    %phi_samp(iter+1,:) = theta_curr.phi; 
    sig2_samp(iter+1) = theta_curr.sig2;  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%% update predictions
    zt_curr=zt_samp(:,iter); 
    [wt_prop,zt_curr]=NNGP_predict_test1(zt_curr,Xe,beta_curr,theta_curr,array_rho_p,array_C_p,...
    funname,wNt);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   


    wt_samp(:,iter+1)=wt_prop;
    wt_curr=wt_samp(:,iter+1); 
    zt_samp(:,iter+1)=zt_curr;
    % restart w's 
    w_samp(:,1)=w_samp(:,2);
    w_samp(:,2)=w_samp(:,3);
    
    
end

  out = [beta_samp,sig2_samp,phi_samp,tau2_samp];

end

