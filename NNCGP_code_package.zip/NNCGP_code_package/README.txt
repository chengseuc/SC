

Matlab code accompanying NNCGP Markov chain Monte Carlo by S.Cheng. This folder contains the code for simulation and real data analysis mentioned in the paper. Simulations and real data application were carried out using the software MATLAB R2018a.


********************************** SAMPLERS AVAILABLE *****************************************

The samplers are available for two level multifidelity level systems with 2D spatial referenced input space, univariate output


Fully nonnested NNCGP samplers:
               - NNCGP_nonnested_main , Sec .3&4 

Fully nested NNCGP samplers:
               - NNCGP_nested_main , Sec .3&4 

Single layer NNGP samplers:
               - NNGP_main , Sec .4

NNCGP model for NOAA satellite observations:
               - NNGP_NOAA_main, Sec .5, loading, tuning and apply NNGP model on data sets
               - NNCGP_NOAA_main, Sec .5, apply NNCGP model on tuned data sets


****************************************** SYNTAX ********************************************** 

Each sampler can be executed by calling the corresponding function by following the syntax, as shown in NNCGP_nest_data_generate.m and NNCGP_nonnest_data_generate.m

     out = [out1 out2 ... outN] = sampler_name(data1,data2,predict_input,MCMC_iteration_num,m)

   
$$Inputs-  

    variable name          Meaning
     
     data1:                Input dataset of low fidelity level     
     data2:                Input dataset of high fidelity level
     predict_input:        The spatial location input for prediction of high fidelity level
     MCMC_iteration_num:   Number of MCMC iterations
     m:                    Number of nearest neighbors choose by users

$$Outputs-
     
    variable name          Meaning
     
     beta1_samp:   The sampler of mean parameter for low fidelity level, see sec.3 
     beta2_samp:   The sampler of mean parameter for high fidelity level, see sec.3 
     sig2_samp1:   The sampler of variance parameter for low fidelity level, see sec.3
     sig2_samp2:   The sampler of variance parameter for high fidelity level, see sec.3
     phi1_samp:    The sampler of spatial effect parameter for low fidelity level, see sec.3
     phi2_samp:    The sampler of spatial effect parameter for high fidelity level, see sec.3    
     tau2_samp1:   The sampler of nugget effect for low fidelity level, see sec.3
     tau2_samp2:   The sampler of nugget effect for high fidelity level, see sec.3
     zeta_samp:    The sampler of scalor parameter of two fidelity levels, see sec.3
     zt:          The sampler of predicted values of high fidelity level, see sec.3
