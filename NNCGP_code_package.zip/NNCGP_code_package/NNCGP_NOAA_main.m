function [out,zt2] = NNCGP_NOAA_main(data1,data2,obsloce0,niter,m)


% inputs--

% data1:  dataset of NOAA 14, should be a 3 column matrix with column 1 as
% observation, column 2 as longitude location and column 3 as latitude
% location;

% data2:  dataset of NOAA 15, should be the same structure as data1

% obsloce0:  the prediction location input, should be a 2 column matrix
% with column 1 as lingitude and column 2 as latitude

% niter:  number of iterations in MCMC(choose by user)

% m:  number of nearest neighbors(choose by user)




% outputs--

% out: a niter by 15 matrix with

% column 1 - 3: mean parameter beta_1, sec.4,5

% column 4 - 6: mean parameter beta_2, sec.4,5

% column 7: varance parameter sigma_1^2, sec.4,5

% column 8: varance parameter sigma_2^2, sec.4,5

% column 9 - 10: spatial effect parameter phi_1 of 2D anisotropic setting, sec.4,5  

% column 11 - 12: spatial effect parameter phi_2 of 2D anisotropic setting, sec.4,5  

% column 13: nugget effect parameter tau_1^2, sec.4,5 

% column 14: nugget effect parameter tau_2^2, sec.4,5 

% column 15: scalor parameter zeta, sec.4,5



Zvec_orig14=data1(:,1);
xlocvec_orig14=data1(:,2);
ylocvec_orig14=data1(:,3);
N14= size(Zvec_orig14,1);

zvec_orig15_data = data2(:,1);
xloc15_data = data2(:,2);
yloc15_data = data2(:,3);
N15= size(zvec_orig15_data,1);

index_total14=xlocvec_orig14;% different sorting may be used;%(xlocvec_orig-min(X)).^1+(ylocvec_orig-min(Y)).^1;
index_total_vec14=reshape(index_total14,N14,1);
[~, ind_I_vec14]=sort(index_total_vec14);

Zvec_sorted14=Zvec_orig14(ind_I_vec14);
xloc_sorted14=xlocvec_orig14(ind_I_vec14);
yloc_sorted14=ylocvec_orig14(ind_I_vec14);


Zvec_orig15=zvec_orig15_data;
xlocvec_orig15=xloc15_data;
ylocvec_orig15=yloc15_data;

index_total15=xlocvec_orig15;% different sorting may be used;%(xlocvec_orig-min(X)).^1+(ylocvec_orig-min(Y)).^1;
index_total_vec15=reshape(index_total15,length(Zvec_orig15),1);
[~, ind_I_vec15]=sort(index_total_vec15);

Zvec_sorted15=Zvec_orig15(ind_I_vec15);
xloc_sorted15=xlocvec_orig15(ind_I_vec15);
yloc_sorted15=ylocvec_orig15(ind_I_vec15);


obsloce=obsloce0; 

Ne=size(obsloce,1);

    obsloc_sorted1 = [xloc_sorted14,yloc_sorted14];
    
    obsloc_sorted2 = [xloc_sorted15,yloc_sorted15];
    
    [array_C1,array_rho1, B_rowin1, B_colin1,neigh_index1]=NeighD_AllD(obsloc_sorted1,m);
    neigh_index1 = int32(neigh_index1);
    
    [array_C2,array_rho2, B_rowin2, B_colin2,neigh_index2]=NeighD_AllD(obsloc_sorted2,m);
    neigh_index2 = int32(neigh_index2);

    [array_C_p1,array_rho_p1, B_rowin_p1, B_colin_p1,neigh_index_p1]=NeighD_AllDpr(obsloc_sorted1,m,obsloc_sorted2);
    neigh_index_p1 = int32(neigh_index_p1);

    [array_C_p01,array_rho_p01, B_rowin_p01, B_colin_p01,neigh_index_p01]=NeighD_AllDpr(obsloc_sorted1,m,obsloce);
    neigh_index_p01 = int32(neigh_index_p01);

    [array_C_p02,array_rho_p02, B_rowin_p02, B_colin_p02,neigh_index_p02]=NeighD_AllDpr(obsloc_sorted2,m,obsloce);
    neigh_index_p02 = int32(neigh_index_p02);

    X14=[ones(size(xloc_sorted14)) xloc_sorted14 yloc_sorted14];
    X15=[ones(size(xloc_sorted15)) xloc_sorted15 yloc_sorted15];
    Xe=[ones(size(obsloce,1),1) obsloce(:,1) obsloce(:,2)];



    %% MCMC iteration


    p=size(X14,2);

    %priors

    % beta N(mu,V)
    mubeta1=0; 
    Vbeta1=1000; 

    mubeta2=0; 
    Vbeta2=1000; 

    % zeta N(mu,V)
    muzeta=0;
    Vzeta=1000;

    % tau IG(a,b)
    a1=2;
    b1=1;

    a2=2;
    b2=1;

    %sig2 IG(c,d)
    c1=2;
    d1=1;

    c2=2;
    d2=1;

    
    %% plan for MCMC iterations
 % here X is the sorted prediction variable (intercept, lati and longi)
    
%%

    ind_I_vec1 = ind_I_vec14;
    ind_I_vec2 = ind_I_vec15;
    
    y1 = Zvec_sorted14;
    z2 = Zvec_sorted15;
    n2 = size(z2,1);
    
    % MCMC iterration
    
    beta1_samp = zeros([p niter]); 
    beta2_samp = zeros([p niter]); 
    zeta_samp = zeros(niter,1);
    phi1_sampX = zeros(niter,1);
    phi2_sampX = zeros(niter,1);
    phi1_sampY = zeros(niter,1);
    phi2_sampY = zeros(niter,1);
    tau2_samp1 = zeros(niter,1);
    tau2_samp2 = zeros(niter,1);
    sig2_samp1 = zeros(niter,1);
    sig2_samp2 = zeros(niter,1);
 
    % initial value
    
    beta1_samp(:,1)=X14\y1;
    beta2_samp(:,1)=X15\(z2-mean(y1));
    sig2_samp1(1)=var(y1-X14*beta1_samp(:,1));
    sig2_samp2(1)=var(z2-mean(y1)-X15*beta2_samp(:,1));
    tau2_samp1(1)=0.01;
    tau2_samp2(1)=0.01;
    phi1_sampX(1)=1;
    phi2_sampX(1)=1;
    phi1_sampY(1)=1;
    phi2_sampY(1)=1;
    zeta_samp(1)=1;
    

    y12 = z2-mean(z2)+mean(y1);
    
    
    
    
    wt1 = zeros([Ne,1]);
    wt2 = zeros([Ne,1]);
    zt1 = zeros([Ne,1]);
    zt2 = zeros([Ne,1]);

n1 = length(y1);
n2 = length(z2);

tic

for iter = 1:niter

   
    % a test of all parameters
    if mod(iter,10)<=0 % remainer, inter/50
    display(['Iteration: ' int2str(iter) ]);
    disp([beta1_curr',beta2_curr',sig2_curr1,sig2_curr2,phi1_currX,phi1_currY,phi2_currX,phi2_currY,tau2_curr1,tau2_curr2,zeta_curr]);
    end
    
    %% joint model
    
    
    %iterations
    beta1_curr = beta1_samp(:,iter);
    beta2_curr = beta2_samp(:,iter);
    zeta_curr =  zeta_samp(iter);
    sig2_curr1 = sig2_samp1(iter);
    sig2_curr2 = sig2_samp2(iter);
    tau2_curr1 = tau2_samp1(iter);
    tau2_curr2 = tau2_samp2(iter);
    phi1_currX = phi1_sampX(iter);
    phi2_currX = phi2_sampX(iter);
    phi1_currY = phi1_sampY(iter);
    phi2_currY = phi2_sampY(iter);
    
  
theta1.tau2 = tau2_curr1;
theta1.sig2 = sig2_curr1;
theta1.phi = [phi1_currX phi1_currY];
theta1.covflag = 0;
theta1.Beta = X14*beta1_curr;    
theta1.zetaz = zeta_curr;
    
theta2.tau2 = tau2_curr2;
theta2.sig2 = sig2_curr2;
theta2.phi = [phi2_currX phi2_currY];
theta2.covflag = 0;
theta2.Beta = X15*beta2_curr;
    
    
% update w1(S^(1))
    
    [~,W1_prop]=condapp_w_multilevel_combine_marginal_y0_c(y1,theta1,array_rho1,array_C1,B_rowin1,B_colin1);

W1_curr = W1_prop;

  indx2=(length(z2)*m);
  w_nei=W1_curr(B_colin_p1(1:indx2),:);
  wNt1 = reshape(w_nei, m, indx2/m);


% prediction of w1(S^(2))

theta1p.tau2 = tau2_curr1;
theta1p.sig2 = sig2_curr1;
theta1p.phi = [phi1_currX phi1_currY];
theta1p.covflag = 0;
theta1p.Beta = X15*beta1_curr;    
theta1p.zetaz = zeta_curr;

[~,y12] = predictw1_fun_y01_c(y12,array_C_p1,array_rho_p1,theta1p,wNt1);


% update w2(S^(2)) 

[~,W2_prop]=condapp_w_multilevel_combine_marginal_y1_c(y12,z2,zeta_curr,...
        theta2,array_rho2,array_C2,B_rowin2,B_colin2);

W2_curr = W2_prop;

    % tau1
    a1_curr = a1 + 0.5*n1;
    b1_curr = b1 + 0.5*(y1-X14*beta1_curr-W1_curr)'*(y1-X14*beta1_curr-W1_curr);
    tau2_samp1(iter+1) = 1/gamrnd(a1_curr,1/b1_curr);
    tau2_curr1 = tau2_samp1(iter+1);

    %tau2 
    a2_curr = a2 + 0.5*n2;
    b2_curr = b2 + 0.5*(z2-zeta_curr.*y12-X15*beta2_curr-W2_curr)'*(z2-zeta_curr.*y12-X15*beta2_curr-W2_curr);
    tau2_samp2(iter+1) = 1/gamrnd(a2_curr,1/b2_curr);
    tau2_curr2 = tau2_samp2(iter+1);

    %beta1
    sig_beta1_inv = 1/Vbeta1 + (1/tau2_curr1)*(X14'*X14);
    mu_ast_beta1 = 1/Vbeta1 * mubeta1 + X14'*(y1-W1_curr)/tau2_curr1;
    mu_post_beta1 = sig_beta1_inv\mu_ast_beta1;
    R_beta1 = chol(sig_beta1_inv);
    beta1_samp(:,iter+1) = mu_post_beta1 + R_beta1\normrnd(0,1,[p,1]);
    beta1_curr = beta1_samp(:,iter+1);
    
    %beta2
    sig_beta2_inv = 1/Vbeta2+(1/tau2_curr2)*(X15'*X15);
    mu_ast_beta2 = mubeta2/Vbeta2+X15'*(z2-zeta_curr.*y12-W2_curr)/tau2_curr2;
    mu_post_beta2 = sig_beta2_inv\mu_ast_beta2;
    R_beta2 = chol(sig_beta2_inv);
    beta2_samp(:,iter+1) = mu_post_beta2 + R_beta2 \ normrnd(0,1,[p,1]);
    beta2_curr = beta2_samp(:,iter+1);

    %zeta
    sig2_zeta_inv=1/Vzeta + y12'*y12/tau2_curr2;
    mu_ast_zeta = muzeta/Vzeta + y12'*(z2-X15*beta2_curr-W2_curr)/tau2_curr2;
    mu_post_zeta = mu_ast_zeta/sig2_zeta_inv;
    Rzeta = 1/sqrt(sig2_zeta_inv);
    zeta_curr = mu_post_zeta+ Rzeta*normrnd(0,1,1);

    zeta_samp(iter+1)=zeta_curr;

%update phi1 & phi2

deltaphi = 0.2;

deltasig = 0.2;

theta1.tau2 = tau2_curr1;
theta1.sig2 = sig2_curr1;
theta1.phi = [phi1_currX phi1_currX];
theta1.covflag = 0;
theta1.Beta = X14*beta1_curr;

theta2.tau2 = tau2_curr2;
theta2.sig2 = sig2_curr2;
theta2.phi = [phi2_currY phi2_currY];
theta2.covflag = 0;
theta2.Beta = X15*beta2_curr;

out1 = metroh_phi3_sig_c_anso(W1_curr,theta1,array_rho1,array_C1,neigh_index1,deltasig,deltaphi,c1,d1);

out2 = metroh_phi3_sig_c_anso(W2_curr,theta2,array_rho2,array_C2,neigh_index2,deltasig,deltaphi,c2,d2);


sig2_curr1 = out1(1);
sig2_curr2 = out2(1);
phi1_currX = out1(2);
phi2_currX = out2(2);
phi1_currY = out1(3);
phi2_currY = out2(3);


sig2_samp1(iter+1) = sig2_curr1;
sig2_samp2(iter+1) = sig2_curr2;
phi1_sampX(iter+1) = phi1_currX;
phi2_sampX(iter+1) = phi2_currX;
phi1_sampY(iter+1) = phi1_currY;
phi2_sampY(iter+1) = phi2_currY;


    %% the prediction
     
theta1.tau2 = tau2_curr1;
theta1.sig2 = sig2_curr1;
theta1.phi = [phi1_currX phi1_currY];
theta1.covflag = 0;
theta1.Beta = Xe*beta1_curr;    
   
theta2.tau2 = tau2_curr2;
theta2.sig2 = sig2_curr2;
theta2.phi = [phi2_currX phi2_currY];
theta2.covflag = 0;
theta2.Beta = Xe*beta2_curr;
    
    wt1_curr = wt1(:,iter);
    wt2_curr = wt2(:,iter);
    zt1_curr = zt1(:,iter);
    zt2_curr = zt2(:,iter);


% update lv1  
  indx2=(Ne*m);
  w_nei=W1_curr(B_colin_p01(1:indx2),:);
  wNt01 = reshape(w_nei, m, indx2/m);   
  [~,zt1_curr] = predictw1_fun_y01_c(zt1_curr,array_C_p01,array_rho_p01,theta1,wNt01);


% update lv2
  indx2=(Ne*m);
  w_nei=W2_curr(B_colin_p02(1:indx2),:);
  wNt02 = reshape(w_nei, m, indx2/m);
  [~,zt2_curr]=predictw1_fun_y12_c(zt1_curr,zt2_curr,array_C_p02,array_rho_p02,theta2,wNt02,zeta_curr);


wt1(:,iter+1)=wt1_curr;
wt2(:,iter+1)=wt2_curr;
zt1(:,iter+1)=zt1_curr;
zt2(:,iter+1)=zt2_curr;

    
    
end
       
out = [beta1_samp',beta2_samp',sig2_samp1,sig2_samp2,phi1_sampX,phi1_sampY,phi2_sampX,phi2_sampY,tau2_samp1,tau2_samp2,zeta_samp];


    
    
end







 