function [cond_sig2,w_prop]=...
    update_w_test1(Zdata,Xm,B_rowin,B_colin,beta_curr,theta,array_rho,array_C,funname)


nsub = length(Zdata); % number of observations or outputs
m = size(array_C, 1);  % number of nearest neighbors

sig2 = theta.sig2;
tau2 = theta.tau2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% update w:
% cond_sig2=zeros([nsub 1]);
% cond_sig2(1)=sig2;    

% BSall_vec = zeros(length(B_rowin), 1);

% for indd=2:m    

%     rhos=NNGP_Corr_AllD(theta, array_rho(1:(indd-1),1,indd,:), funname);
%     Ctemp=NNGP_Corr_AllD(theta, array_C(1:(indd-1),1:(indd-1),indd,:), funname);
%     %Ctemp_rho = Ctemp\rhos;   % nonzero elements in A 
%     %cond_sig2(indd)=sig2_curr-sig2_curr*(rhos.'*Ctemp_rho);
%     L = chol(Ctemp, 'lower');
%     Lrho = L\rhos;
%     cond_sig2(indd) = sig2 - sig2*(Lrho.'*Lrho);
%     %BSall_vec_temp1=[BSall_vec_temp1 (-Ctemp_rho'))];
%     ind_start = indd*(indd-1)/2 - indd + 2;
%     ind_end = indd*(indd-1)/2;
%     BSall_vec(ind_start:ind_end) = Lrho.'/L;
% end
         
% for indd=(m+1):nsub

%     rhos=NNGP_Corr_AllD(theta, array_rho(:,1,indd,:), funname);
%     Ctemp=NNGP_Corr_AllD(theta, array_C(:,:,indd,:), funname);
%     %Ctemp_rho = Ctemp\rhos;
%     %cond_sig2(indd)=sig2_curr-sig2_curr*(rhos'*Ctemp_rho);
%     L = chol(Ctemp, 'lower');
%     Lrho = L\rhos;
%     cond_sig2(indd) = sig2 - sig2*(Lrho.'*Lrho);
%     ind_start = m*(m-1)/2 + m*(indd-m-1) + 1;
%     ind_end = ind_start + m - 1;
%     BSall_vec(ind_start:ind_end) = Lrho.'/L;
% end

%% use C mex code
[cond_sig2, BSall_vec] = buildAtest1(array_C, array_rho, theta);

cond_sig2(1)= theta.sig2; 

BSall = speye(nsub) - sparse(B_rowin, B_colin, BSall_vec, nsub, nsub);
Finv_vec = cond_sig2.^(-1);
Cinv_curr = BSall'*spdiags(Finv_vec, 0, nsub, nsub)*BSall;
Vsinv = Cinv_curr + (1/tau2)*speye(nsub);
% chol_Vsinv = chol(Vsinv);
% ws_post_mean = chol_Vsinv\(chol_Vsinv.'\((Zdata-Xm*beta_curr)*(1/tau2)));
% w_new = chol_Vsinv\randn(nsub,1);
[chol_Vsinv, ~, perm] = chol(Vsinv, 'vector');
res = (Zdata-Xm*beta_curr)*(1/tau2);
ws_post_mean(perm,1) = chol_Vsinv\(chol_Vsinv.'\(res(perm)));
b = randn(nsub,1);
w_new(perm,1) = chol_Vsinv\(b(perm));
w_prop = w_new + ws_post_mean;


end
    