/*
% Author: Pulong Ma University of Cincinnati
% Date: June 24, 2018
% Last Modified by: Pulong Ma
% Last Modified Date: June 24, 2018
% Last Modified time: 10:48:11
*/

/* Signature:  
mex -v loglik.c -lmwblas -lmwlapack -R2018a

In MATLAB:
tic;[out1,out2] = loglik(array_C, array_rho, theta, w_curr, neigh_index);toc;


*/


#include "mex.h"
#include "matrix.h"
#include <math.h>
#include "blas.h"
#include "tmwtypes.h"
//#include "mexutil.h"

#ifndef INT32_T
# if   TMW_BITS_PER_INT   == 32
#  define  INT32_T int
# elif TMW_BITS_PER_LONG  == 32
#  define  INT32_T long
# elif TMW_BITS_PER_SCHAR == 32
#  define  INT32_T signed char
# elif TMW_BITS_PER_SHRT  == 32
#  define  INT32_T short
# endif
#endif
#ifdef INT32_T
 typedef INT32_T int32_T;
#endif



#ifndef dpotrf
#	define dpotrf dpotrf_     // cholesky decomposition
#endif

#ifndef dpotri
#	define dpotri dpotri_     // inverse of a symmetric matrix using cholesky decomposition
#endif

#ifndef dgemm
#	define dgemm dgemm_       // matrix product 
#endif

#ifndef dsymm
#	define dsymm dsymm_       // matrix product with a symmetric matrix
#endif

#ifndef dtrtrs
#	define dtrtrs dtrtrs_     // triangular solver
#endif


#ifndef dpotrs
#	define dpotrs dpotrs_     // solver with a symmetric pd matrix using Cholesky
#endif

// #ifndef dposv
// #   define dposv dposv_	     // solver with positive definite matrix using Cholesky
// #endif

#ifndef dcopy
#	define dcopy dcopy_       // make a copy 
#endif

#ifndef ddot
#	define ddot ddot_         // dot product of two arrays
#endif



// funciton declaration 
// avoid waring about implicit declaration of function .... in C99 [-Wimplicit-...] 
void dpotrs(char*, mwSize*, mwSize*, double*, mwSize*, double*, mwSize*, mwSignedIndex*);
void dposv(char*, mwSize*, mwSize*, double*, mwSize*, double*, mwSize*, mwSignedIndex*);
void NNGP_loglik(double*, mwSize*, double*, mwSize*, mwSize,
	 double, double*, mwSize, mwSize, double*, INT32_T*, double*, double*);
mwIndex sub2indcolm(const mwSize*, mwSize, mwIndex*);
mwIndex sub2indrowm(const mwSize*, mwSize, mwIndex*);


// function definition
void expcor(double* phi, double* dist, mwIndex indd, const mwSize* Dim, double* cormat, mwSize* nrow, mwSize* ncol)
{

	mwIndex i=0, j=0, k=0;
	mwIndex ind = 0;
	double temp = 0.0;
	for(i=0; i<nrow[0]; i++){
		for(j=0; j<ncol[0]; j++){
			temp = 0.0;
			for(k=0; k<Dim[3]; k++){
				//cormat[i][j] += dist[i][j][k]*dist[i][j][k]/(phi[k]*phi[k]);
				ind = i+j*Dim[0]+indd*Dim[0]*Dim[1]+k*Dim[0]*Dim[1]*Dim[2];
				//cormat[i+j*nrow[0]] += dist[ind]*dist[ind]/(phi[k]*phi[k]);
				temp += dist[ind]*dist[ind]/(phi[k]*phi[k]);			
			}
			//cormat[i][j] = exp(-sqrt(cormat[i][j]));
			//cormat[i+j*nrow[0]] = exp(-sqrt(cormat[i+j*nrow[0]]));
			cormat[i+j*nrow[0]] = exp(-sqrt(temp));
		}
	}

	//return cormat;
	
}






void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{

	// Argument checks

	if(nrhs!=5){
		mexErrMsgTxt("Five input arguments are required.");
	}


	double* dist_C = (double*) mxGetData(prhs[0]);
	mwSize* DimC = (mwSize*) mxGetDimensions(prhs[0]);
	mwSize nDim = mxGetNumberOfDimensions(prhs[0]);

	double* dist_rho = (double*) mxGetData(prhs[1]);
	mwSize* DimR = (mwSize*) mxGetDimensions(prhs[1]);
	mwSize nDimR = mxGetNumberOfDimensions(prhs[1]);

	if(nDim!=nDimR){
		mexErrMsgIdAndTxt("MATLAB:NNGPloglik:dist_C:dimensionmismatch",
			"Distance matrix dimensions do not match.");
	}


	const mwSignedIndex n = DimC[2]; // total number of observations

    mwSignedIndex nn = DimC[0]*DimC[1];  // total number of elements in correlation matrix
    const mwSignedIndex m = DimC[0];  // number of rows, or nearest neighbors

	//mxClassID *classIDflags;
	//mwIndex jstruct;

	int nfields = mxGetNumberOfFields(prhs[2]);
	//mexPrintf("Number of fields: %d\n", nfields);


	double* phi = (double*) mxGetData(mxGetField(prhs[2], 0, "phi"));
	double sig2 = mxGetScalar(mxGetField(prhs[2], 0, "sig2"));
	double covflag = mxGetScalar(mxGetField(prhs[2], 0, "covflag"));

	if(nfields<3){
		mexErrMsgIdAndTxt("MATLAB:NNGPloglik:nfields:illegalvalue", 
		"More parameters in the correlation function are needed.");	
	}


	// get w and neigh_index
	double* w = (double*) mxGetData(prhs[3]);
	if(!mxIsClass(prhs[4], "int32")){
		mexErrMsgIdAndTxt("MATLAB:NNGPloglik:prhs[4]:illegalvalue" ,"The input prhs[4] is not passed with type int32.\n");
	}
	
	//int* neigh_index = (int*) mxGetData(prhs[4]);  // not machine independent
	INT32_T *neigh_index = (INT32_T*)mxGetData(prhs[4]);

	// allocate arrays
	double* cond_sig2 = (double*) mxCalloc(n, sizeof(double));
	cond_sig2[0] = sig2;
	double* wmus = (double*) mxCalloc(n, sizeof(double));

    	// set output 
	plhs[0] = mxCreateDoubleMatrix(n, 1, mxREAL);
  //	mxSetPr(plhs[0], cond_sig2);
	plhs[1] = mxCreateDoubleMatrix(n, 1, mxREAL);
  //	mxSetPr(plhs[1], wmus);
    cond_sig2 = mxGetDoubles(plhs[0]);
    wmus = mxGetDoubles(plhs[1]);
	// plhs[1] = mxCreateNumericMatrix(n*m, 1, mxINT32_CLASS, mxREAL);
	// mxSetInt32s(plhs[1], neigh_index);

	// mxFree(neigh_index);
    
	NNGP_loglik(dist_C, DimC, dist_rho, DimR, nDim, sig2, phi, m, n, w, neigh_index, cond_sig2, wmus);


	return;
}






void NNGP_loglik(double* dist_C, mwSize* DimC, double* dist_rho, mwSize* DimR, mwSize nDim, double sig2,
	 double* phi, mwSize m, mwSize n, double* w, INT32_T* neigh_index, double* cond_sig2, double* wmus){


	mwSize* cDim = (mwSize*) malloc(nDim * sizeof(mwSize));
	mwSize* rDim = (mwSize*) malloc(nDim * sizeof(mwSize));

	mwIndex i;
	for(i=0; i<nDim; i++){
		cDim[i] = DimC[i];
		rDim[i] = DimR[i];
	}

	mwSignedIndex mm;
	mwSignedIndex ind_start, ind_end;


	double* Ctemp = (double*) malloc(m*m*sizeof(double));
	double* Rho = (double*) malloc(m*sizeof(double));
	double* Ctemp_rho = (double*) malloc(m*sizeof(double));


	// variables used in lapack/blas routines
	char* lower = "L";
	char* upper = "U";
	char* ntran = "N";
	char* ytran = "T";
	char* lside = "L";
	char* rside = "R";
	double one = 1.0;
	double zero = 0.0;
    const mwSignedIndex incOne = 1;
    mwSignedIndex info;     /* flag for success in dpotrf, spotrf, dpotri, spotri */

    mwIndex indd, k;
    double temp = 0.0;

    // Begin for-loop for the first m observations 
	for(indd=1; indd<m; indd++){

		cDim[0] = indd;
		cDim[1] = indd;
		rDim[0] = indd;
		mm = indd;  // number of rows in Ctemp_rho

		Ctemp = (double*) realloc(Ctemp, cDim[0]*cDim[1]*sizeof(double));
		Rho = (double*) realloc(Rho, rDim[0]*rDim[1]*sizeof(double));
		Ctemp_rho = (double*) realloc(Ctemp_rho, mm*sizeof(double));

		// construct correlation function
		expcor(phi, dist_C, indd, DimC, Ctemp, &cDim[0], &cDim[1]);
		expcor(phi, dist_rho, indd, DimR, Rho, &cDim[0], &rDim[1]);

		// solve for  Ctemp*X=Rho
		dcopy(&mm, Rho, &incOne, Ctemp_rho, &incOne);
		dposv(lower, &cDim[0], &rDim[1], Ctemp, &cDim[0], Ctemp_rho, &cDim[0], &info);

		// if(info!=0){
		// 	mexErrMsgIdAndTxt("MATLAB:exp_mex:dposv:illegalvalue",
		// 		"failed to solver the linear system.");
		// }

		// compute cond_sig2
		cond_sig2[indd] = sig2 - sig2*ddot(&mm, Rho, &incOne, Ctemp_rho, &incOne);
		

		// compute wmus
		// mexPrintf("\nfirst m neighbors:\n");
		// 	for(mwIndex k=0; k<mm; k++){
		// 	mexPrintf("neigh_index=%d, w=%4g\n", neigh_index[k+m*indd-1], w[neigh_index[k+m*indd-1]]);
		// 	}
		//wmus[indd] = ddot(&mm, Ctemp_rho, &incOne, w);
		temp = 0.0;
		for(k=0; k<mm; k++){
			temp += Ctemp_rho[k]*w[neigh_index[k+m*indd-1]];
		}
		wmus[indd] = temp;

	}    

    // Begin for-loop for observations with m nearest neighbors
    mm = m;
	Ctemp = (double*) realloc(Ctemp, DimC[0]*DimC[1]*sizeof(double));
	Rho = (double*) realloc(Rho, mm*sizeof(double));
	Ctemp_rho = (double*) realloc(Ctemp_rho, mm*sizeof(double));


	for(indd=m; indd<n; indd++){

		expcor(phi, dist_C, indd, DimC, Ctemp, &DimC[0], &DimC[1]);
		expcor(phi, dist_rho, indd, DimR, Rho, &DimR[0], &DimR[1]);

		// solve for  Ctemp*X=Rho
		dcopy(&mm, Rho, &incOne, Ctemp_rho, &incOne);

		//dpotrs(lower, &rDim[0], &rDim[1], Ctemp, &rDim[0], Ctemp_rho, &rDim[0], &info);
		dposv(lower, &DimC[0], &DimR[1], Ctemp, &DimC[0], Ctemp_rho, &DimC[0], &info);
		// Ctemp now stores its lower cholesky factor 

		// if(info!=0){
		// 	mexPrintf("indd=%d\n", indd);
		// 	mexErrMsgIdAndTxt("MATLAB:buildA:dposv:illegalvalue",
		// 		"failed to solver the linear system.");
		// }

		// compute cond_sig2
		cond_sig2[indd] = sig2 - sig2*ddot(&mm, Rho, &incOne, Ctemp_rho, &incOne);
		
		// compute wmus
		// if(indd<m+2){
		// 	mexPrintf("\n m neighbors:\n");
		// 	for(mwIndex k=0; k<mm; k++){
		// 	mexPrintf("neigh_index=%d, w=%4g\n", neigh_index[k+m*indd], w[neigh_index[k+m*indd]-1]);
		// 	}
		// }

		temp = 0.0;
		for(k=0; k<mm; k++){
			temp += Ctemp_rho[k]*w[neigh_index[k+m*indd]-1];
		}
		wmus[indd] = temp;		


	}

	free(rDim);
	free(cDim);
	free(Ctemp);
	free(Rho);
	free(Ctemp_rho);

	lower = NULL;
	upper = NULL;
	ntran = NULL;
	ytran = NULL;
	lside = NULL;
	rside = NULL;

	return;
}

