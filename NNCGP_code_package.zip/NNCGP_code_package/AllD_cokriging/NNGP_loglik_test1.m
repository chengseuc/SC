function [wsigma2s, wmus, loglike_curr]=NNGP_loglik_test1(w_curr,neigh_index, ...
         theta,array_rho,array_C,funname)
    
% sig2 = theta.sig2;

% nsub=length(w_curr);
% m=size(neigh_index, 1);
% wsigma2s=zeros([nsub 1]);
% wsigma2s(1)=sig2;
% wmus=zeros([nsub 1]);

% for indd=2:nsub
%     % for i=1:Dim_x
%     %     array_C1{i} = array_C{i}(1:min(indd-1,m),1:min(indd-1,m),indd);
%     %     array_rho1{i} = array_rho{i}(1:min(indd-1,m), indd);
%     % end

%     % slightly faster
%     index = min(indd-1,m);
%     %array_C1=cellfun(@(x) x(1:index, 1:index, indd), array_C, 'UniformOutput', false);
%     %array_rho1 = cellfun(@(x) x(1:index, indd), array_rho, 'UniformOutput', false);

%     rhos=NNGP_Corr_AllD(theta, array_rho(1:index,1, indd, :), funname);
%     Ctemp=NNGP_Corr_AllD(theta, array_C(1:index, 1:index, indd, :), funname);
%     %M=Ctemp\rhos;         
%     %wsigma2s(indd)=sig2_curr-sig2_curr*(rhos'*M);
%     %wmus(indd)=M'*(w_curr(neigh_index(1:index,indd)));
%     L = chol(Ctemp, 'lower');
%     Lrho = L\rhos;
%     wsigma2s(indd)=sig2-sig2*(Lrho.'*Lrho);
%     wmus(indd)=Lrho.'*(L\(w_curr(neigh_index(1:index,indd))));
% end


% C mex code
 [wsigma2s,wmus] = logliktest1(array_C, array_rho, theta, w_curr, neigh_index);

wsigma2s(1) = theta.sig2;

loglike_w=-1/2*(log(wsigma2s))-(1/2) *(wsigma2s.^(-1)).*((w_curr-wmus).^2);
loglike_curr=sum(loglike_w);


       
end