function [theta_curr,loglike_curr,wmus,wsigma2s,Delta]=NNGP_MwH_Gibbs_test1(w_curr,...
    neigh_index,loglike_curr,theta_curr,prior,Delta,array_rho,array_C,funname)




%nsub=length(w_curr);
Dim=size(array_C);
Dim_x = Dim(end);
% extract parameters in prior distributions
a2 = prior.a2;
b2 = prior.b2;
a3 = prior.a3;
b3 = prior.b3;
c1 = prior.c1;
c2 = prior.c2;

% extract proposal variance 
% mean_sig2 = Delta.mean_sig2;
% cov_sig2 = Delta.cov_sig2;
% mean_phi = Delta.mean_phi;
% cov_phi = Delta.cov_phi;
% olditer = Delta.iter;

%%%%%% update sig2
% random walk for sig2
sig2_curr = theta_curr.sig2;
sig2_prop=lognrnd(log(sig2_curr), Delta.sigma2,1);
if sig2_prop<=c1 || sig2_prop>c2
    sig2_prop = sig2_curr;
end
theta_prop = theta_curr;
theta_prop.sig2 = sig2_prop;

% loglikelihood evaluation
[wsigma2s, wmus, loglike_prop]=NNGP_loglik_test1(w_curr,neigh_index,...
    theta_prop, array_rho,array_C,funname);

% log of prior density
log_prior_curr = -(a2+1)*log(sig2_curr) - b2/sig2_curr;
log_prior_prop = -(a2+1)*log(sig2_prop) - b2/sig2_prop;

% from sig2_curr --> sig2_prop.
log_sig2_tran = -log(sig2_prop)-(log(sig2_prop)-log(sig2_curr))^2/(2*Delta.sigma2^2);
% from sig2_prop --> sig2_curr.
log_sig2_rtran = -log(sig2_curr)-(log(sig2_curr)-log(sig2_prop))^2/(2*Delta.sigma2^2);

log_diff=(loglike_prop-loglike_curr)+ (log_prior_prop-log_prior_curr) + (log_sig2_rtran-log_sig2_tran);

a_unif=rand(1); 
if a_unif<=exp(log_diff)
    sig2_curr=sig2_prop;
    loglike_curr=loglike_prop;
end

theta_curr.sig2 = sig2_curr;

%% update proposal variance
% [cov_sig2, mean_sig2, Delta.sigma2] = update_prop_var(sig2_curr, cov_sig2, mean_sig2, olditer);
% Delta.mean_sig2 = mean_sig2;
% Delta.cov_sig2 = cov_sig2;


%%%%% update phi_s

Dim_x = 1;

phi_prop = zeros(Dim_x,1);

for k=1:(Dim_x)
    
    theta_prop = theta_curr;
    phi_curr = theta_curr.phi;
    % random walk for phi_x 
    phi_prop(k)=lognrnd(log(phi_curr(k)), Delta.phi(k), 1);
    if phi_prop(k)<=a3(k) || phi_prop(k)>b3(k)
        phi_prop(k) = phi_curr(k);
    end

    theta_prop.phi(k) = phi_prop(k);
    theta_prop.phi(2) = phi_prop(k);
    
    % loglikelihood evaluation
    [wsigma2s, wmus, loglike_prop]=NNGP_loglik_test1(w_curr,neigh_index, ...
        theta_prop, array_rho,array_C,funname);

    % log prior density
    log_prior_curr = 0;
    log_prior_prop = 0;
           
    % from phi_curr_X --> phi_prop_X.
    log_pr_tran = -log(phi_prop(k))-(log(phi_prop(k))-log(phi_curr(k)))^2/(2*Delta.phi(k)^2);
    % from phi_prop_X --> phi_curr_X.
    log_pr_rtran = -log(phi_curr(k))-(log(phi_curr(k))-log(phi_prop(k)))^2/(2*Delta.phi(k)^2);


    log_diff=(loglike_prop-loglike_curr)+ (log_prior_prop-log_prior_curr) + (log_pr_rtran-log_pr_tran);

    a_unif=rand(1); 

    if a_unif<=exp(log_diff)
        phi_curr(k)=phi_prop(k);
        loglike_curr=loglike_prop;
    end

    theta_curr.phi(k) = phi_curr(k);
    theta_curr.phi(2) = phi_curr(k);
    
end


%% clear variables 


%% update proposal variance
% [cov_phi(1), mean_phi(1), Delta.phi(1)] = update_prop_var(phi_s_curr(1), cov_phi(1), mean_phi(1), olditer);
% Delta.mean_phi(1) = mean_phi(1);
% Delta.cov_phi(1) = cov_phi(1);




end