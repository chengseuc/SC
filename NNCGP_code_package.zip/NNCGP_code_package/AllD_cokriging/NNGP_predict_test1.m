function [ytt,ztt]=NNGP_predict_test1(zt_curr,Xe,beta_curr,theta,array_rho_p,array_C_p,...
funname,wNt)

% Ne = length(zt_curr); % number of prediction locations
% % Dim = size(array_C_p); 
% % Dim_x = Dim(end);
% m = size(array_C_p, 1); % number of neighbors, same across all prediction locations

% sig2 = theta.sig2;
% tau2 = theta.tau2;

% Predict y:
% ytt = zeros(Ne,1);
% ztt = zeros(Ne,1);
% cond_sig2=zeros([Ne 1]);
% Ftinv_Bt_wNt=zeros(Ne,1);


% for k=1:Ne  

%     rhos=NNGP_Corr_AllD(theta, array_rho_p(:,1,k,:), funname);
%     Ctemp=NNGP_Corr_AllD(theta, array_C_p(:,:,k,:), funname);

%     BSall_vec = Ctemp\rhos;
%     cond_sig2(k)=sig2-sig2*(rhos'*BSall_vec);
%     Ftinv_Bt_wNt(k)=cond_sig2(k)^(-1)*(BSall_vec'*wNt(:,k));

%     L = chol(Ctemp, 'lower');
%     Lrho = L\rhos;
%     cond_sig2(k)=sig2-sig2*(Lrho.'*Lrho);
%     Ftinv_Bt_wNt(k)=(Lrho.'*(L\wNt(:,k)));

%     % Dinv_yt_XB=(1/tau2)*(zt_curr(k)-Xe(k,:)*beta_curr);
%     % Mut=Dinv_yt_XB+Ftinv_Bt_wNt;
%     % Vtt=(1/tau2+ cond_sig2(k)^(-1))^(-1);
%     %VBeta=(Xe(k,:)/Sig_beta_inv)*Xe(k,:)'; 

%     % Uncertainty 
%     %Vtt2(k)=(sig2+tau2)-sig2*(rhos'*((Ctemp+tau2_curr*eye(m))\rhos));
%     % % Predict y
%     % ytt(k) = Vtt*Mut + Vtt.^(0.5)*randn(1);
%     % % Predict z
%     % ztt(k) = Xe(k,:)*beta_curr+ytt(k) + sqrt(tau2_curr)*randn(1);
% end

% Dinv_yt_XB=(1/tau2)*(zt_curr-Xe*beta_curr);
% Mut=Dinv_yt_XB+cond_sig2.^(-1).*Ftinv_Bt_wNt;
% Vtt=(1/tau2+ cond_sig2.^(-1)).^(-1);


%% C mex code
Ne = length(zt_curr); % number of prediction locations
tau2 = theta.tau2;
[cond_sig2, Ftinv_Bt_wNt] = predicttest1(array_C_p, array_rho_p, theta, wNt);
Dinv_yt_XB=(1/tau2)*(zt_curr-Xe*beta_curr);
Mut=Dinv_yt_XB+cond_sig2.^(-1).*Ftinv_Bt_wNt;
Vtt=(1/tau2+ cond_sig2.^(-1)).^(-1);


% Predict w
ytt = Vtt.*Mut + Vtt.^(0.5).*randn(Ne,1);
% Predict z
ztt = Xe*beta_curr + ytt + sqrt(tau2)*randn(Ne,1);



end
