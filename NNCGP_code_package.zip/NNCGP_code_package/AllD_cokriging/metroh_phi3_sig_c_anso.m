function out = metroh_phi3_sig_c_anso(W1,theta,array_rho,array_C,neigh_index,deltasig,deltaphi,a,b)


%sig part

sig = theta.sig2;
t = normrnd(log(sig),deltasig,1);
sigstar = exp(t);

if sigstar>10*var(W1)||sigstar<0.0000001
    sigstar = sig;
end



theta2 = theta;
theta2.sig2 = sigstar;

[cond_sig1,wmus] = logliktest1(array_C,array_rho,theta,W1,neigh_index);

cond_sig1(1) = theta.sig2;

cond_sig1(cond_sig1==0) = mean(cond_sig1);

logit1=-1/2*(log(cond_sig1))-(1/2) *(cond_sig1.^(-1)).*((W1-wmus).^2);
logit1=sum(logit1);

[cond_sig2,wmus] = logliktest1(array_C,array_rho,theta2,W1,neigh_index);

cond_sig2(1) = theta2.sig2;

cond_sig2(cond_sig2==0) = mean(cond_sig2);

logit2=-1/2*(log(cond_sig2))-(1/2) *(cond_sig2.^(-1)).*((W1-wmus).^2);
logit2=sum(logit2);


   r=logit2-logit1+log(sigstar)-log(sig)+(-(a+1)*log(sigstar)-b/sigstar)-(-(a+1)*log(sig)-b/sig);
   u=log(rand());
   if u<r
     outsig = sigstar;
   else
       outsig = sig;
   end
   
   
   
theta.sig2 = outsig;

phiX=theta.phi(1);
phiY=theta.phi(2);
t = normrnd(log(phiX),deltaphi,1);
phistar = exp(t);

if phistar>10000||phistar<1/20
    phistar = phiX;
end



theta2 = theta;
theta2.phi = [phistar phiY];

[cond_sig1,wmus1] = logliktest1(array_C, array_rho,theta,W1,neigh_index);

cond_sig1(1) = theta.sig2;

cond_sig1(cond_sig1==0) = mean(cond_sig1);

logit1=-1/2*(log(cond_sig1))-(1/2) *(cond_sig1.^(-1)).*((W1-wmus1).^2);
logit1=sum(logit1);

[cond_sig2,wmus2] = logliktest1(array_C, array_rho,theta2,W1,neigh_index);

cond_sig2(1) = theta2.sig2;

cond_sig2(cond_sig2==0) = mean(cond_sig2);

logit2=-1/2*(log(cond_sig2))-(1/2) *(cond_sig2.^(-1)).*((W1-wmus2).^2);
logit2=sum(logit2);

   r=logit2-logit1+log(phistar)-log(phiX);
   u=log(rand());
   if u<r
     outphiX = phistar;
   else
     outphiX = phiX;
   end
   
   
   

theta2.phi(1) = outphiX;
   
phiX=theta2.phi(1);
phiY=theta2.phi(2);
t = normrnd(log(phiY),deltaphi,1);
phistar = exp(t);

if phistar>10000||phistar<1/20
    phistar = phiY;
end


theta3 = theta2;
theta3.phi = [phiX phistar];

[cond_sig1,wmus1] = logliktest1(array_C, array_rho,theta2,W1,neigh_index);

cond_sig1(1) = theta2.sig2;

cond_sig1(cond_sig1==0) = mean(cond_sig1);

logit1=-1/2*(log(cond_sig1))-(1/2) *(cond_sig1.^(-1)).*((W1-wmus1).^2);
logit1=sum(logit1);

[cond_sig2,wmus2] = logliktest1(array_C, array_rho,theta3,W1,neigh_index);

cond_sig2(1) = theta3.sig2;

cond_sig2(cond_sig2==0) = mean(cond_sig2);

logit2=-1/2*(log(cond_sig2))-(1/2) *(cond_sig2.^(-1)).*((W1-wmus2).^2);
logit2=sum(logit2);

   r=logit2-logit1+log(phistar)-log(phiY);
   u=log(rand());
   if u<r
     outphiY = phistar;
   else
     outphiY = phiY;
   end
   
   
   
   out = [outsig,outphiX,outphiY];


end



