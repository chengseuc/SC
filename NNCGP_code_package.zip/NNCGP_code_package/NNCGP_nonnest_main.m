function [out,zt2] = NNCGP_nonnest_main(data1,data2,obsloce0,niter,m)


% inputs--

% data1:  dataset of low fidelity level, should be a 3 column matrix with column 1 as
% observation, column 2 as longitude location and column 3 as latitude
% location;

% data2:  dataset of high fidelity level, should be the same structure as
% data1

% obsloce0:  the prediction location input, should be a 2 column matrix
% with column 1 as lingitude and column 2 as latitude

% niter:  number of iterations in MCMC(choose by user)

% m:  number of nearest neighbors(choose by user)




% outputs--

% out: a niter by 9 matrix with

% column 1: mean parameter beta_1, sec.4

% column 2: mean parameter beta_2, sec.4

% column 3: varance parameter sigma_1^2, sec.4

% column 4: varance parameter sigma_2^2, sec.4

% column 5: spatial effect parameter phi_1 of 2D isotropic setting, sec.4  

% column 6: spatial effect parameter phi_2 of 2D isotropic setting, sec.4  

% column 7: nugget effect parameter tau_1^2, sec.4 

% column 8: nugget effect parameter tau_2^2, sec.4

% column 9: scalor parameter zeta, sec.4



    Zvec_orig1=data1(:,1);
    xlocvec_orig1=data1(:,2);
    ylocvec_orig1=data1(:,3);

    Zvec_orig2=data2(:,1);
    xlocvec_orig2=data2(:,2);
    ylocvec_orig2=data2(:,3);
    
    n1 = size(data1,1);
    n2 = size(data2,1);

    index_total1=xlocvec_orig1;
    index_total_vec1=reshape(index_total1,n1,1);
    [~, ind_I_vec1]=sort(index_total_vec1);

    index_total2=xlocvec_orig2;
    index_total_vec2=reshape(index_total2,n2,1);
    [~, ind_I_vec2]=sort(index_total_vec2);
    
    Zvec_sorted1=Zvec_orig1(ind_I_vec1);
    xloc_sorted1=xlocvec_orig1(ind_I_vec1);
    yloc_sorted1=ylocvec_orig1(ind_I_vec1);

    Zvec_sorted2=Zvec_orig2(ind_I_vec2);
    xloc_sorted2=xlocvec_orig2(ind_I_vec2);
    yloc_sorted2=ylocvec_orig2(ind_I_vec2);
  
    obsloce=[xloc_sorted2,yloc_sorted2];
    
    obsloc_sorted=[xloc_sorted1,yloc_sorted1];
 
    Ne = size(obsloce0,1);
    
    obsloc_sorted1 = [xloc_sorted1,yloc_sorted1];
    
    obsloc_sorted2 = [xloc_sorted2,yloc_sorted2];
    
    [array_C1,array_rho1, B_rowin1, B_colin1,neigh_index1]=NeighD_AllD(obsloc_sorted1,m);
    neigh_index1 = int32(neigh_index1);
    
    [array_C2,array_rho2, B_rowin2, B_colin2,neigh_index2]=NeighD_AllD(obsloc_sorted2,m);
    neigh_index2 = int32(neigh_index2);

    [array_C_p1,array_rho_p1, B_rowin_p1, B_colin_p1,neigh_index_p1]=NeighD_AllDpr(obsloc_sorted,m,obsloce);
    neigh_index_p1 = int32(neigh_index_p1);
    
    [array_C_p01,array_rho_p01, B_rowin_p01, B_colin_p01,neigh_index_p01]=NeighD_AllDpr(obsloc_sorted1,m,obsloce0);
    neigh_index_p01 = int32(neigh_index_p01);
    
    [array_C_p02,array_rho_p02, B_rowin_p02, B_colin_p02,neigh_index_p02]=NeighD_AllDpr(obsloc_sorted2,m,obsloce0);
    neigh_index_p02 = int32(neigh_index_p02);

    
    % beta N(mu,V)
    mubeta1=0; 
    Vbeta1=1000; 

    mubeta2=0; 
    Vbeta2=1000; 

    % zeta N(mu,V)
    muzeta=0;
    Vzeta=1000;

    % tau IG(a,b)
    a1=2;
    b1=1;

    a2=2;
    b2=1;

    %sig2 IG(c,d)
    c1=2;
    d1=1;

    c2=2;
    d2=1;

    
 %% plan for MCMC iterations
   
%%

   
    y12 = Zvec_sorted2-mean(Zvec_sorted2)+mean(Zvec_sorted1);
    y1 = Zvec_orig1;
    y2 = Zvec_orig2;
    
    
    % MCMC iterration
    beta1_samp = zeros(niter,1);
    beta2_samp = zeros(niter,1);
    zeta_samp = zeros(niter,1);
    phi1_samp = zeros(niter,1);
    phi2_samp = zeros(niter,1);
    tau2_samp1 = zeros(niter,1);
    tau2_samp2 = zeros(niter,1);
    sig2_samp1 = zeros(niter,1);
    sig2_samp2 = zeros(niter,1);
 
    % initial value
    
    beta1_samp(1)=mean(y1);
    beta2_samp(1)=mean(y2)-mean(y1);
    sig2_samp1(1)=var(y1);
    sig2_samp2(1)=abs(var(y2)-var(y1));
    tau2_samp1(1)=var(y1)/10;
    tau2_samp2(1)=var(y2)/10;
    phi1_samp(1)=10;
    phi2_samp(1)=10;
    zeta_samp(1)=1;
    zeta_res = mean(y2)/mean(y1);


    %% MCMC iteration

    %% Prediction sets
    

    wt1 = zeros([Ne,1]);
    wt2 = zeros([Ne,1]);
    zt1 = zeros([Ne,1]);
    zt2 = zeros([Ne,1]);

W1_curr = y1-mean(y1);

W1_curr = W1_curr(ind_I_vec1);

W2_curr = Zvec_sorted2 - mean (Zvec_sorted2);


tic

for iter = 1:niter

   
    % a test of all parameters
    if mod(iter,20)<=0 % remainer, inter/50
    display(['Iteration: ' int2str(iter) ]);
    disp([beta1_curr,beta2_curr,sig2_curr1,sig2_curr2,phi1_curr,phi2_curr,tau2_curr1,tau2_curr2,zeta_curr]);
    end
    
    %% joint model
    
    
    %iterations
    beta1_curr = beta1_samp(iter);
    beta2_curr = beta2_samp(iter);
    zeta_curr =  zeta_samp(iter);
    sig2_curr1 = sig2_samp1(iter);
    sig2_curr2 = sig2_samp2(iter);
    tau2_curr1 = tau2_samp1(iter);
    tau2_curr2 = tau2_samp2(iter);
    phi1_curr = phi1_samp(iter);
    phi2_curr = phi2_samp(iter);
    
  
    % tau1

    a1_curr = a1 + 0.5*n1;
    b1_curr = b1 + 0.5*(y1(ind_I_vec1)-beta1_curr-W1_curr)'*(y1(ind_I_vec1)-beta1_curr-W1_curr);
    tau2_curr1 = 1/gamrnd(a1_curr,1/b1_curr);
    if tau2_curr1>min(sig2_curr1/10,var(y1)/10)
        tau2_curr1 = min(sig2_curr1/10,var(y1)/10);
    end
    tau2_samp1(iter+1) = tau2_curr1;


    %beta1

    sig_beta1_inv = 1/Vbeta1 + n1/tau2_curr1;
    mu_ast_beta1 = 1/Vbeta1 * mubeta1 + sum(y1(ind_I_vec1)-W1_curr)/tau2_curr1;
    mu_post_beta1 = mu_ast_beta1/sig_beta1_inv;
    R_beta1 = 1/sqrt(sig_beta1_inv);
    beta1_samp(iter+1) = mu_post_beta1 + R_beta1* normrnd(0,1,1);
    beta1_curr = beta1_samp(iter+1);
    
 
%update phi1 & phi2

deltaphi = 0.2;

deltasig = 0.2;

theta1.tau2 = tau2_curr1;
theta1.sig2 = sig2_curr1;
theta1.phi = [1/phi1_curr 1/phi1_curr];
theta1.covflag = 0;
theta1.Beta = beta1_curr;

out1 = metroh_phi4_sig_c(W1_curr,theta1,array_rho1,array_C1,neigh_index1,deltaphi);
phi1_curr = 1/out1;

[cond_sig,wmus] = logliktest1(array_C1,array_rho1,theta1,W1_curr,neigh_index1);
cond_sig(1) = sig2_curr1;
condsig1 = cond_sig/sig2_curr1;
logsig2_1 = (W1_curr-wmus).^2.*((condsig1).^(-1));
sum1 = sum(logsig2_1);
c1_curr = c1 + 0.5*n1;
d1_curr = d1 + 0.5*sum1;
sig2_samp1(iter+1) = 1/ gamrnd(c1_curr,1/d1_curr);
sig2_curr1 = sig2_samp1(iter+1);


sig2_samp1(iter+1) = sig2_curr1;
phi1_samp(iter+1) = phi1_curr;

theta1.tau2 = tau2_curr1;
theta1.sig2 = sig2_curr1;
theta1.phi = [1/phi1_curr 1/phi1_curr];
theta1.covflag = 0;
theta1.Beta = beta1_curr;

    
[ws_post_mean1,W1_curr]=condapp_w_multilevel_combine_marginal_y0_c(y1(ind_I_vec1),theta1,array_rho1,array_C1,B_rowin1,B_colin1);

    

%W1_curr = w1(ind_I_vec1);




    %tau2 
    a2_curr = a2 + 0.5*n2;
    b2_curr = b2 + 0.5*(Zvec_sorted2-zeta_curr.*y12-beta2_curr-W2_curr)'*(Zvec_sorted2-zeta_curr.*y12-beta2_curr-W2_curr);
    tau2_curr2 = 1/gamrnd(a2_curr,1/b2_curr);
    if tau2_curr2>var(Zvec_sorted2)/10
        tau2_curr2 = var(Zvec_sorted2)/10;
    end
    tau2_samp2(iter+1) = tau2_curr2;
    
    %beta2
    sig_beta2_inv = 1/Vbeta2+n2/tau2_curr2;
    mu_ast_beta2 = mubeta2/Vbeta2+sum(Zvec_sorted2-zeta_curr.*y12-W2_curr)/tau2_curr2;
    mu_post_beta2 = mu_ast_beta2/sig_beta2_inv;
    R_beta2 = 1/sqrt(sig_beta2_inv);
    beta2_samp(iter+1) = mu_post_beta2 + R_beta2 * normrnd(0,1,1);
    beta2_curr = beta2_samp(iter+1);

    %zeta
    sig2_zeta_inv=1/Vzeta + y12'*y12/tau2_curr2;
    mu_ast_zeta = muzeta/Vzeta + y12'*(Zvec_sorted2-beta2_curr-W2_curr)/tau2_curr2;
    mu_post_zeta = mu_ast_zeta/sig2_zeta_inv;
    Rzeta = 1/sqrt(sig2_zeta_inv);     
    zeta_curr = mu_post_zeta+ Rzeta*normrnd(0,1,1);
    if zeta_curr>max(zeta_res,1/zeta_res)||zeta_curr<min(zeta_res,1/zeta_res)
        closevalue = [zeta_res 1/zeta_res];
        [~,closeindex] = min(abs(zeta_curr-closevalue));
        zeta_curr = closevalue(closeindex);
    end 
    
    zeta_samp(iter+1) = zeta_curr;

    
%update phi2

deltaphi = 0.2;

deltasig = 0.2;

theta2.tau2 = tau2_curr2;
theta2.sig2 = sig2_curr2;
theta2.phi = [1/phi2_curr 1/phi2_curr];
theta2.covflag = 0;
theta2.Beta = beta2_curr;

out2 = metroh_phi3_sig_c(W2_curr,theta2,array_rho2,array_C2,neigh_index2,deltasig,deltaphi,c2,d2,var(y2));
sig2_curr2 = out2(1);
phi2_curr = 1/out2(2);

sig2_samp2(iter+1) = sig2_curr2;
phi2_samp(iter+1) = phi2_curr;

% prediction of w1(S^(2))

  indx2=(n2*m);
  w_nei=W1_curr(B_colin_p1(1:indx2),:);
  wNt1 = reshape(w_nei, m, indx2/m);

[w12,y12] = predictw1_fun_y01_c(y12,array_C_p1,array_rho_p1,theta1,wNt1);

% update w2(S^(2)) 
[ws_post_mean2,W2_curr]=condapp_w_multilevel_combine_marginal_y1_c(y12,Zvec_sorted2,zeta_curr,...
        theta2,array_rho2,array_C2,B_rowin2,B_colin2);

    
    
    
    %% the prediction
     
theta1.tau2 = tau2_curr1;
theta1.sig2 = sig2_curr1;
theta1.phi = [1/phi1_curr 1/phi1_curr];
theta1.covflag = 0;
theta1.Beta = beta1_curr;    
   
theta2.tau2 = tau2_curr2;
theta2.sig2 = sig2_curr2;
theta2.phi = [1/phi2_curr 1/phi2_curr];
theta2.covflag = 0;
theta2.Beta = beta2_curr;
    
    wt1_curr = wt1(:,iter);
    wt2_curr = wt2(:,iter);
    zt1_curr = zt1(:,iter);
    zt2_curr = zt2(:,iter);


% update lv1  
  indx2=(Ne*m);
  w_nei=W1_curr(B_colin_p01(1:indx2),:);
  wNt01 = reshape(w_nei, m, indx2/m);   
  [~,zt1_curr] = predictw1_fun_y01_c(zt1_curr,array_C_p01,array_rho_p01,theta1,wNt01);


% update lv2
  indx2=(Ne*m);
  w_nei=W2_curr(B_colin_p02(1:indx2),:);
  wNt02 = reshape(w_nei, m, indx2/m);
  [~,zt2_curr]=predictw1_fun_y12_c(zt1_curr,zt2_curr,array_C_p02,array_rho_p02,theta2,wNt02,zeta_curr);


wt1(:,iter+1)=wt1_curr;
wt2(:,iter+1)=wt2_curr;
zt1(:,iter+1)=zt1_curr;
zt2(:,iter+1)=zt2_curr;

    
    

end
        

  out = [beta1_samp,beta2_samp,sig2_samp1,sig2_samp2,phi1_samp,phi2_samp,tau2_samp1,tau2_samp2,zeta_samp];


end
