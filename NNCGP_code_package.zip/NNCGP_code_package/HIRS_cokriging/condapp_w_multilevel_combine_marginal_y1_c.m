function [ws_post_mean,w_prop]=condapp_w_multilevel_combine_marginal_y1_c(y1,y2,zeta_curr,...
        theta,array_rho,array_C,B_rowin,B_colin)

   
nsub = length(y2);

% update w:


[cond_sig2, BSall_vec] = buildAtest1(array_C, array_rho, theta);

cond_sig2(1)=theta.sig2;

    BSall=sparse(B_rowin, B_colin,-BSall_vec,(nsub), (nsub))+sparse(1:(nsub),1:(nsub),1);
    Finv_vec=(cond_sig2).^(-1);
    Finv_temp=sparse(1:(nsub),1:(nsub),Finv_vec);
    Cinv_curr=(BSall')*Finv_temp*BSall;
    Dinvdiag=sparse(1:(nsub),1:(nsub),1/(theta.tau2));
    Vsinv=sparse(Cinv_curr+Dinvdiag);
    
    
    %diag_temp=diag(Cinv_curr)+1/tau2_curr;
    %diag(Vsinv)=diag_temp;
    
    %[sig2_curr,phi_curr_X,phi_curr_Y,tau2_curr]
    
    ws_post_mean=Vsinv\((1/(theta.tau2))*(y2-zeta_curr.*y1-theta.Beta));
    w_temp=normrnd(0,1,nsub,1);
    Ltemp = chol(Vsinv,'lower');
    w_new=(Ltemp')\w_temp;
    
    w_prop=w_new+ws_post_mean;





end

