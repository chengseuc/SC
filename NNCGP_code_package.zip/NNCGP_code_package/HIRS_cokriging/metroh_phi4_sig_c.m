function out = metroh_phi4_sig_c(W1,theta,array_rho,array_C,neigh_index,deltaphi)


%sig part

phi=theta.phi(1);
t = normrnd(log(phi),deltaphi,1);
phistar = exp(t);

theta2 = theta;
theta2.phi = [phistar phistar];

[cond_sig1,wmus1] = logliktest1(array_C, array_rho,theta,W1,neigh_index);

cond_sig1(1) = theta.sig2;

logit1=-1/2*(log(cond_sig1))-(1/2) *(cond_sig1.^(-1)).*((W1-wmus1).^2);
logit1=sum(logit1);

[cond_sig2,wmus2] = logliktest1(array_C, array_rho,theta2,W1,neigh_index);

cond_sig2(1) = theta2.sig2;

logit2=-1/2*(log(cond_sig2))-(1/2) *(cond_sig2.^(-1)).*((W1-wmus2).^2);
logit2=sum(logit2);

logphistar = -log(phistar) - (log(phistar)-log(phi))^2/(2*deltaphi^2);
logphi = -log(phi) - (log(phi)-log(phistar))^2/(2*deltaphi^2);

   r=logit2-logit1+logphi-logphistar;
   u=log(rand());
   if u<r
     outphi = phistar;
   else
     outphi = phi;
   end
   
   out = outphi;


end



