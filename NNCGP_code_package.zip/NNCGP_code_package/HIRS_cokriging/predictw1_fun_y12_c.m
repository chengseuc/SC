
function [wt,zt]=predictw1_fun_y12_c(yt1,zt2_curr,array_C_p,array_rho_p,theta,wNt,zeta)

beta2=theta.Beta;
tau22=theta.tau2;


Ne = length(zt2_curr); % number of prediction locations

[cond_sig2, wmus] = predicttest1(array_C_p, array_rho_p, theta, wNt);

V2 = ((tau22)^(-1)+(cond_sig2.^(-1))).^(-1);
mu_ast2 = (zt2_curr-zeta*yt1-beta2)*((tau22)^(-1)) + wmus.*(cond_sig2.^(-1));
mu_post2 = V2.* mu_ast2;

    wt = mu_post2 + V2.^(0.5).*randn(Ne,1);
    zt = zeta*yt1+beta2+wt+normrnd(0,sqrt(tau22));

end