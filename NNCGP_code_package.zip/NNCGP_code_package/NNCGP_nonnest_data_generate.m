
clear all; close all;
% load covariance function
% add functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load functions to generate random variables
% Load separable model MCMC_operations
%addpath ./GP_operations;

% load functions to generate random variables 

% load NNGP operations
 addpath ~/NNGPfunctions
 addpath ~\AllD_cokriging
 addpath ~\NNCGP_code_package
% load Data

 

    B1= 10;
    B2= 1;
    
    
    sigma1_orin = 2;
    tau1_orin = 0.1;
    phi1_orin = 10;

    sigma2_orin= 1;
    tau2_orin = 0.05;
    phi2_orin = 10;
  

    t_nugget = 0.001;


%%%%% Grid reference constuction %%%%%%%

N = [50 50];
x = (1:N(1))/N(1);
y = (1:N(2))/N(2);

coordr = [kron(ones(N(2),1),x') kron(y',ones(N(1),1))];

n0 = N(1)*N(2);
n1 = 5000;
n2 = 500;



coord1=rand(n1,2);
coord2=rand(n2,2);

%%%%% check if S1, S2 intersects each other %%%%%%%

check = not(isempty(intersect(intersect(coord1,coord2),coordr)));
while check
coord1=rand(n1,2);
coord2=rand(n2,2);
check = not(isempty(intersect(intersect(coord1,coord2),coordr)));
end


coordall1 = [coordr;coord1];
coordall2 = [coordr;coord2];
%coordall1 = sortrows(coordall1,2);
%coordall2 = sortrows(coordall2,2);
coordall = [coord1;coord2;coordr];

coordX = [ones(n0+n1+n2,1) coordall];

beta_zeta_orin = [1 0 0];
zeta1_orin = 1;

    D = pdist(coordall);
    D = squareform(D);
    R1 = exp(-phi1_orin*D)+t_nugget*eye((n0+n1+n2));
    R2 = exp(-phi2_orin*D)+t_nugget*eye((n0+n1+n2));

    Q_R1 = chol(R1); 
    Q_R2 = chol(R2); 

    x1=ones((n0+n1+n2),1);
    x2=ones((n0+n1+n2),1);

    w10 = sigma1_orin*Q_R1'*normrnd(0,1,[(n0+n1+n2),1]);
    y10 = x1*B1+w10+normrnd(0,sqrt(tau1_orin),[(n0+n1+n2),1]);
    w20 = sigma2_orin*Q_R2'*normrnd(0,1,[(n0+n1+n2),1]);
    y20 = zeta1_orin.*(x2*B1+w10)+x2*B2+w20+normrnd(0,sqrt(tau2_orin),[(n0+n1+n2),1]);

    w1 = w10(1:n1);
    y1 = y10(1:n1);
    y120 = y10((n1+1):(n2+n1));
    w2 = w20((n1+1):(n2+n1));
    w22 = w2;
    y2 = y20((n1+1):(n2+n1));
    wref1 = w10((n2+n1+1):(n2+n1+n0));
    yref1 = y10((n2+n1+1):(n2+n1+n0));
    wref2 = w20((n2+n1+1):(n2+n1+n0));
    yref2 = y20((n2+n1+1):(n2+n1+n0));

    data10 = [y1 coord1];
    data20 = [y2 coord2];
    data120 = [y120 coord2];
    dataref1 = [yref1 coordr];
    dataref2 = [yref2 coordr];

    



longipref1 = dataref1(:,2);
latipref1 = dataref1(:,3);
longipref2 = dataref2(:,2);
latipref2 = dataref2(:,3);



  chunkx = [50 80]'; chunky = [20 80]'; widthx = [20 20]'; widthy = [20 20]';
  
chunkx = chunkx/100;
chunky = chunky/100;
widthx = widthx/100;
widthy = widthy/100;
  
  chunk = [];
  
  
data1 = data10;
data2 = data20;
data12 = data120;
data22 = [];

  
  for i = 1:size(chunkx,1)
     n_size = size(data2,1);
  for j = 1:n_size
      if and(data20(j,2)>chunkx(i),data20(j,2)<chunkx(i)+widthx(i)) && and(data20(j,3)>chunky(i),data20(j,3)<chunky(i)+widthy(i)) 
  data2 (j,:) = 0;
  data12 (j,:) = 0;
  w22(j) = 0;
  data22 = [data22; data20(j,:)];
      end
  end
  end
  
  data2 = data2((data2(:,1)~=0),:);
  data12 = data12((data12(:,1)~=0),:);
  w22 = w22((w22~=0),:);
  
  
    
    z1 = data1(:,1);
    z2 = data2(:,1);
    z120 = data12(:,1);
    z2test = data22(:,1);
    
longip1 = data1(:,2);
latip1 = data1(:,3);
longip20 = data20(:,2);
latip20 = data20(:,3);
longip2 = data2(:,2);
latip2 = data2(:,3);
longip12 = data22(:,2);
latip12 = data22(:,3);

obsloce0 = data22(:,2:3);

niter = 25000;

m=10;

data2 = data22;

mean(y1)/mean(y2)


[out,zt] = NNCGP_nonnest_main(data1,data22,obsloce0,niter,m);

beta1_samp = out(:,1);
beta2_samp = out(:,2);
sig2_samp1 = out(:,3);
sig2_samp2 = out(:,4);
phi1_samp = out(:,5);
phi2_samp = out(:,6);
tau2_samp1 = out(:,7);
tau2_samp2 = out(:,8);
zeta_samp = out(:,9);

  save('test1.mat','beta1_samp','phi1_samp','tau2_samp1','sig2_samp1','beta2_samp','phi2_samp','tau2_samp2','sig2_samp2','zeta_samp','zt');



out = [beta1_samp,beta2_samp,sig2_samp1,sig2_samp2,phi1_samp,phi2_samp,tau2_samp1,tau2_samp2,zeta_samp];



