
% This code includes the modules of :
% loading NOAA 14 and NOAA 15 data sets
% tuning before applying NNGP model
% The tuned data sets are also ready to apply NNCGP model, in the code
% NNCGP_NOAA_main

 addpath ~/NNGPfunctions
 addpath ~/AllD_cokriging
 addpath ~\Data; 
 addpath ~\LHS; 
 


load('N14data_day60to69.mat')
load('N15data_day60to69.mat')

data15=[hirsData_N15(1).channelData(5,:)' hirsData_N15(1).longitude' hirsData_N15(1).latitude'];
data14=[hirsData_N14(1).channelData(5,:)' hirsData_N14(1).longitude' hirsData_N14(1).latitude'];

data14_1=data14(data14(:,3)<= 70&data14(:,3)>=-70,:); % choose certain data from column 3, from -70 to 70
data14_11=data14_1(data14_1(:,2)<= 360&data14_1(:,2)>=0,:); % choose again from column 2, from -180 to 180

data15_1=data15(data15(:,3)<= 70&data15(:,3)>=-70,:); % choose certain data from column 3, from -70 to 70
data15_10=data15_1(data15_1(:,2)<= 360&data15_1(:,2)>=0,:); % choose again from column 2, from -180 to 180



nomiss=sum(data14_11==-3.276700000000000e+03); % delete something
data14_11(data14_11==-3.276700000000000e+03) = nan;
data15_10(data15_10==-3.276700000000000e+03) = nan;

data15_11 = data15_10;

zt14=data14_11(:,1); %data
longi14=data14_11(:,2); %longitude
lati14=data14_11(:,3); %latitude

zt15=data15_11(:,1); %data
longi15=data15_11(:,2); %longitude
lati15=data15_11(:,3); %latitude

figure(1);
colormap(jet)
flipud(scatter(longi14,lati14,10,zt14,'filled','s'));
xlim([min(longi14),max(longi14)]);
ylim([min(lati14),max(lati14)]);
caxis([min(zt14),max(zt14)])
h = colorbar;

figure(2);
colormap(jet)
flipud(scatter(longi15,lati15,10,zt15,'filled','s'));
xlim([min(longi15),max(longi15)]);
ylim([min(lati15),max(lati15)]);
caxis([min(zt15),max(zt15)])
h = colorbar;




[row, col] = find(isnan(zt14)); % findout the missing in data

zt14(row)=[]; %delete na from data
longi14(row)=[];
lati14(row)=[];

[row, col] = find(isnan(zt15)); % findout the missing in data

zt15(row)=[]; %delete na from data
longi15(row)=[];
lati15(row)=[];


DATT14=[zt14 longi14 lati14]; %data without missing
DATT15=[zt15 longi15 lati15];

[C,Unq14,ic] = unique(DATT14(:,2:3),'rows');
[C,Unq15,ic] = unique(DATT15(:,2:3),'rows');


zt14=zt14(Unq14); %set new z, longi and lati with no repetition
longi14=longi14(Unq14);
lati14=lati14(Unq14);
zt15=zt15(Unq15); %set new z, longi and lati with no repetition
longi15=longi15(Unq15);
lati15=lati15(Unq15);



%lm linear model fitting

AllData14=[longi14 lati14 zt14];
X14=[ones(length(longi14),1) longi14 lati14]; % explanatory variable setting, 1, longi and lati
betas14 = X14\zt14;
res14=zt14-(X14*betas14); % residual

AllData15=[longi15 lati15 zt15];
X15=[ones(length(longi15),1) longi15 lati15]; % explanatory variable setting, 1, longi and lati
betas15 = X15\zt15;
res15=zt15-(X15*betas15); % residual


lon14 =longi14;
lat14 =lati14;
zvec_orig14 =zt14;
lon_orig14=lon14;
lat_orig14=lat14;
xloc14=lon14;
yloc14=lat14;
lon15 =longi15;
lat15 =lati15;
zvec_orig15 =zt15;
lon_orig15=lon15;
lat_orig15=lat15;
xloc15=lon15;
yloc15=lat15;

%%{
%LHS (latin hypercube sampling)
coord14=[xloc14 yloc14];
xobj14=ones(length(zvec_orig14),1);%data(:,6);     % class/categorigal variable
vobj14=1;%[1 2 3 4];     % value of the class

%nsub=5000;    % no of samples used in MSPE
nsub14=100;
niter14=10000;    % no iterations
[ipick14,xsam14,xobs14,oL14,isam14]=cLHS(nsub14,res14,xobj14,vobj14,niter14);
%sample from residual, ipick is its index, xobj is one, vobj is one
cxy14=coord14(ipick14,:);
% plot coordinates of sampled data
%plot(cxy(:,1), cxy(:,2), 'o');

sub_ind14=ipick14;

coord15=[xloc15 yloc15];
xobj15=ones(length(zvec_orig15),1);
vobj15=1;

nsub15=100;
niter15=10000;   
[ipick15,xsam15,xobs15,oL15,isam15]=cLHS(nsub15,res15,xobj15,vobj15,niter15);
cxy15=coord15(ipick15,:);

sub_ind15=ipick15;



% For MSPE:


zvec_orig14(sub_ind14)=[]; % delete sampled data in the original data
xloc14(sub_ind14)=[];
yloc14(sub_ind14)=[];
N14= size(zvec_orig14,1);

zvec_orig15(sub_ind15)=[]; % delete sampled data in the original data
xloc15(sub_ind15)=[];
yloc15(sub_ind15)=[];
N15= size(zvec_orig15,1);


% Sample from N15

data15 = [zvec_orig15 xloc15 yloc15];

data15_test1 = data15(data15(:,2)<100&data15(:,2)>50&data15(:,3)<40&data15(:,3)>25,:);
data15_test = [data15_test1];
testnumber = data15(:,2)<100&data15(:,2)>50&data15(:,3)<40&data15(:,3)>25;
data15_data = data15(~testnumber,:);


zvec_orig15_data = data15_data(:,1);
xloc15_data = data15_data(:,2);
yloc15_data = data15_data(:,3);

zvec_orig15_test = data15_test(:,1);
xloc15_test = data15_test(:,2);
yloc15_test = data15_test(:,3);
                  

figure(1);
colormap(jet)
flipud(scatter(xloc15_data,yloc15_data,10,zvec_orig15_data,'filled','s'));
xlim([min(xloc15_data),max(xloc15_data)]);
ylim([min(yloc15_data),max(yloc15_data)]);
caxis([min(zvec_orig15_data),max(zvec_orig15_data)])
h = colorbar;


figure(2);
colormap(jet)
flipud(scatter(xloc15_test,yloc15_test,10,zvec_orig15_test,'filled','s'));
xlim([min(xloc15_test),max(xloc15_test)]);
ylim([min(yloc15_test),max(yloc15_test)]);
caxis([min(zvec_orig15_data),max(zvec_orig15_data)])
h = colorbar;


%% NNGP

Zvec_orig14=zvec_orig14;
xlocvec_orig14=xloc14;
ylocvec_orig14=yloc14;

index_total14=xlocvec_orig14;% different sorting may be used;%(xlocvec_orig-min(X)).^1+(ylocvec_orig-min(Y)).^1;
index_total_vec14=reshape(index_total14,N14,1);
[~, ind_I_vec14]=sort(index_total_vec14);

%ind_I_vecval(ind_I_vec)=1:(N);

p14=size(X14,2);

Zvec_sorted14=Zvec_orig14(ind_I_vec14);
xloc_sorted14=xlocvec_orig14(ind_I_vec14);
yloc_sorted14=ylocvec_orig14(ind_I_vec14);


Zvec_orig15=zvec_orig15_data;
xlocvec_orig15=xloc15_data;
ylocvec_orig15=yloc15_data;

index_total15=xlocvec_orig15;% different sorting may be used;%(xlocvec_orig-min(X)).^1+(ylocvec_orig-min(Y)).^1;
index_total_vec15=reshape(index_total15,length(Zvec_orig15),1);
[~, ind_I_vec15]=sort(index_total_vec15);

%ind_I_vecval(ind_I_vec)=1:(N);

p15=size(X15,2);

Zvec_sorted15=Zvec_orig15(ind_I_vec15);
xloc_sorted15=xlocvec_orig15(ind_I_vec15);
yloc_sorted15=ylocvec_orig15(ind_I_vec15);




%% PRIDICTION

obsloce=[xloc15_test,yloc15_test]; % combine the two

X15=[ones(size(xloc_sorted15)) xloc_sorted15 yloc_sorted15];
Xe=[ones(size(obsloce,1),1) obsloce(:,1) obsloce(:,2)];

Ne=size(obsloce,1);

 m=10;

    
    obsloc_sorted1 = [xloc_sorted14,yloc_sorted14];
    
    obsloc_sorted2 = [xloc_sorted15,yloc_sorted15];
    
    [array_C1,array_rho1, B_rowin1, B_colin1,neigh_index1]=NeighD_AllD(obsloc_sorted1,m);
    neigh_index1 = int32(neigh_index1);
    
    [array_C2,array_rho2, B_rowin2, B_colin2,neigh_index2]=NeighD_AllD(obsloc_sorted2,m);
    neigh_index2 = int32(neigh_index2);

    [array_C_p1,array_rho_p1, B_rowin_p1, B_colin_p1,neigh_index_p1]=NeighD_AllDpr(obsloc_sorted1,m,obsloc_sorted2);
    neigh_index_p1 = int32(neigh_index_p1);

    [array_C_p01,array_rho_p01, B_rowin_p01, B_colin_p01,neigh_index_p01]=NeighD_AllDpr(obsloc_sorted1,m,obsloce);
    neigh_index_p01 = int32(neigh_index_p01);

    [array_C_p02,array_rho_p02, B_rowin_p02, B_colin_p02,neigh_index_p02]=NeighD_AllDpr(obsloc_sorted2,m,obsloce);
    neigh_index_p02 = int32(neigh_index_p02);

    X14=[ones(size(xloc_sorted14)) xloc_sorted14 yloc_sorted14];
    X15=[ones(size(xloc_sorted15)) xloc_sorted15 yloc_sorted15];
    Xe=[ones(size(obsloce,1),1) obsloce(:,1) obsloce(:,2)];





%% plan for MCMC iterations
Xm=X15; % here X is the sorted prediction variable (intercept, lati and longi)
X = X15;

p=size(X,2);
N= size(Zvec_sorted15,1);


mubeta=zeros(p,1); 
Vbeta=1000;%*eye(p); 
% tau2\sim IG(a1,b1)
a1=2;
b1=0.2;
% sig2 \sim IG(a2,b2)
a2=2;
b2=1;
% phi \sim Unif (0.00001,3)
a3=.00001;
b3=3;

niter=25000;

beta_samp=zeros([p niter]);
phi_sampX=zeros([niter 1]);
phi_sampY=zeros([niter 1]);
tau2_samp=zeros([niter 1]);
sig2_samp=zeros([niter 1]);


zt_samp=zeros([Ne 1]);
Vzt_iter=zeros([Ne 1]);
yt_samp=zeros([Ne 1]);


z2 = Zvec_sorted15;
n2 = size(z2,1);
wp2 = zeros([n2,1]);

Zdata=Zvec_sorted15;

Beta = Xm\Zdata;

w_curr=Zdata-(Xm*Beta);
sig2_samp(1)=var(Zdata-(Xm*Beta));%parr(1); initial value setting
tau2_samp(1)=sig2_samp(1)/20;%parr(4);
phi_sampX(1)=0.0001;
phi_sampY(1)=0.0002;
beta_samp(:,1)=Beta;


c1=0;
c2=var(Zdata-(Xm*Beta))+200;

funname='exponential';
accep_samp=zeros([niter 1]);

%% C++ codes %%

iter=1;

tic
for iter=1:niter
    
    
    
    if mod(iter,20)<=0 % remainer, inter/50
    display(['Iteration: ' int2str(iter) ]);
    disp([beta_curr',sig2_curr,phi_curr_X,phi_curr_Y,tau2_curr,mean(zt_curr)]);
    end
    
 
    
    % update beta
    tau2_curr=tau2_samp(iter);
    Sig_beta_inv=(1/Vbeta)+(1/tau2_curr)*(Xm'*Xm);

    mu_ast_beta=(1/Vbeta)*mubeta+(1/tau2_curr) *Xm'*(Zdata-w_curr);

    mu_post_beta=Sig_beta_inv\mu_ast_beta;
    R=chol(Sig_beta_inv);
    beta_samp(:,iter+1)=mu_post_beta+R\normrnd(0,1,[p,1]);

    beta_curr=beta_samp(:,iter+1);
    phi_curr_X=phi_sampX(iter);
    phi_curr_Y=phi_sampY(iter);
    tau2_curr=tau2_samp(iter);
    sig2_curr=sig2_samp(iter);    
    
    
theta1.tau2 = tau2_curr;
theta1.sig2 = sig2_curr;
theta1.phi = [phi_curr_X phi_curr_Y];
theta1.covflag = 0;
theta1.Beta = Xm*beta_curr;    
   
    
       %updating w_curr
    [ws_post_mean1,W1_prop]=condapp_w_multilevel_combine_marginal_y0_c(Zdata,theta1,array_rho2,array_C2,B_rowin2,B_colin2);

    w_curr = W1_prop;
    
    wp2(:,iter+1)=w_curr;
    
    indx2=(Ne*m);
    w_nei=w_curr(B_colin_p02(1:indx2),:);

    wNt = reshape(w_nei, m, (indx2)/m*1);
    
    % update tau2 (inverse gamma)
    a_new=a1+N/2;
    b_new=b1+0.5*((Zdata-Xm*beta_curr-w_curr)'*(Zdata-Xm*beta_curr-w_curr));
    
    gm_prop=gamrnd(a_new,1/b_new);
    tau2_samp(iter+1)=1/gm_prop;%0.1;%1/gm_prop;

    
    % update (sig2 phi): M-H
    % M-H sigma,phi
    Delta.sigma2=0.1; Delta.phi=0.1;
    
    deltasig = 0.1;deltaphi = 0.1;
    
theta1.tau2 = tau2_curr;
theta1.sig2 = sig2_curr;
theta1.phi = [phi_curr_X phi_curr_Y];
theta1.covflag = 0;
theta1.Beta = Xm*beta_curr;    
    
    
    out1 = metroh_phi3_sig_c_anso(w_curr,theta1,array_rho2,array_C2,neigh_index2,deltasig,deltaphi,a2,b2);

     sig2_samp(iter+1)=out1(1);
     phi_sampX(iter+1)=out1(2); 
     phi_sampY(iter+1)=out1(3);
     sig2_curr = out1(1);
     phi_curr_X = out1(2); 
     phi_curr_Y = out1(3); 
     
thetap.tau2 = tau2_curr;
thetap.sig2 = sig2_curr;
thetap.phi = [phi_curr_X phi_curr_Y];
thetap.covflag = 0;
thetap.Beta = Xe*beta_curr;    
     
     zt_curr=zt_samp(:,iter); 
     
     [~,zt_curr] = predictw1_fun_y01_c(zt_curr,array_C_p02,array_rho_p02,thetap,wNt);

     zt_samp(:,iter+1)=zt_curr;

end

toc

  save('HIRS_singleNNGP.mat','Zvec_sorted15','beta_samp','phi_sampX','phi_sampY','sig2_samp','tau2_samp','zt_samp','obsloce');

 





 